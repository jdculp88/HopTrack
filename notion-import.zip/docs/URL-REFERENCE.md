# HopTrack URL Reference
**Last Updated:** 2026-03-24
**Dev Server:** `http://localhost:3000`
**Production:** TBD (Vercel — Sprint 6)

> This document is updated every sprint as new routes ship. Always current.

---

## 🌐 Public / Marketing

| URL | Description | Auth Required | Status |
|-----|-------------|:---:|--------|
| `/` | Landing page — hero, features, CTA, footer | ❌ | ✅ Live |

---

## 🔐 Auth

| URL | Description | Auth Required | Status |
|-----|-------------|:---:|--------|
| `/login` | Email/password + Google OAuth sign in | ❌ | ✅ Live |
| `/signup` | 2-step registration (account → profile) | ❌ | ✅ Live |
| `/auth/callback` | OAuth redirect handler | ❌ | ✅ Live |

---

## 📱 Consumer App — Main Routes

| URL | Description | Auth Required | Status |
|-----|-------------|:---:|--------|
| `/home` | Social feed, XP bar, weekly stats, check-in cards | ✅ | ✅ Live |
| `/explore` | Brewery discovery, search, list/map toggle | ✅ | ✅ Live |
| `/friends` | Leaderboards, friend list, pending requests | ✅ | ✅ Live |
| `/achievements` | Achievement grid, tier filters, progress | ✅ | ✅ Live |
| `/notifications` | Activity notifications, mark-all-read | ✅ | ✅ Live |
| `/settings` | Profile editor, theme toggle, sign out | ✅ | ✅ Live |

---

## 📱 Consumer App — Dynamic Routes

| URL Pattern | Description | Auth Required | Status |
|-------------|-------------|:---:|--------|
| `/profile/[username]` | User profile — banner, stats, achievements, beer journal | ✅ | ✅ Live |
| `/brewery/[id]` | Brewery detail — hero, tap list, top visitors | ✅ | ✅ Live |
| `/beer/[id]` | Beer detail — ratings, flavor cloud, check-in feed | ✅ | ✅ Live |

**Example URLs (test brewery):**
- `/brewery/a1b2c3d4-e5f6-7890-abcd-ef1234567890` — Pint & Pixel Brewing Co.

---

## 🏭 Brewery Admin Dashboard

> Access via `/brewery-admin` — redirects to your first verified brewery.
> Test brewery ID: `a1b2c3d4-e5f6-7890-abcd-ef1234567890`

| URL Pattern | Description | Auth Required | Status |
|-------------|-------------|:---:|--------|
| `/brewery-admin` | Auto-redirects to first brewery dashboard | ✅ + Brewery Account | ✅ Live |
| `/brewery-admin/[brewery_id]` | Overview — stats, recent check-ins, loyalty summary | ✅ + Brewery Account | ✅ Live |
| `/brewery-admin/[brewery_id]/tap-list` | Manage beers — add, edit, toggle on/off tap | ✅ + Brewery Account | ✅ Live |
| `/brewery-admin/[brewery_id]/analytics` | Charts — daily, DOW, styles, top beers, ratings | ✅ + Brewery Account | ✅ Live |
| `/brewery-admin/[brewery_id]/loyalty` | Loyalty programs + promotions builder | ✅ + Brewery Account | ✅ Live |
| `/brewery-admin/[brewery_id]/settings` | Edit brewery profile, danger zone | ✅ + Brewery Account | ✅ Live |

**Quick Links (Morgan's test brewery):**
- [`/brewery-admin/a1b2c3d4-e5f6-7890-abcd-ef1234567890`](http://localhost:3000/brewery-admin/a1b2c3d4-e5f6-7890-abcd-ef1234567890) — Overview
- [`/brewery-admin/a1b2c3d4-e5f6-7890-abcd-ef1234567890/tap-list`](http://localhost:3000/brewery-admin/a1b2c3d4-e5f6-7890-abcd-ef1234567890/tap-list) — Tap List (10 beers loaded)
- [`/brewery-admin/a1b2c3d4-e5f6-7890-abcd-ef1234567890/analytics`](http://localhost:3000/brewery-admin/a1b2c3d4-e5f6-7890-abcd-ef1234567890/analytics) — Analytics
- [`/brewery-admin/a1b2c3d4-e5f6-7890-abcd-ef1234567890/loyalty`](http://localhost:3000/brewery-admin/a1b2c3d4-e5f6-7890-abcd-ef1234567890/loyalty) — Loyalty & Promotions
- [`/brewery-admin/a1b2c3d4-e5f6-7890-abcd-ef1234567890/settings`](http://localhost:3000/brewery-admin/a1b2c3d4-e5f6-7890-abcd-ef1234567890/settings) — Settings

---

## 🔌 API Routes

| Method | URL | Description | Auth Required | Status |
|--------|-----|-------------|:---:|--------|
| `GET` | `/api/checkins` | Paginated feed of check-ins | ✅ | ✅ Live |
| `POST` | `/api/checkins` | Create a check-in, award XP, check achievements | ✅ | ✅ Live |
| `GET` | `/api/breweries` | Search/nearby breweries (Open Brewery DB + cache) | ✅ | ✅ Live |
| `POST` | `/api/breweries` | Create a brewery | ✅ | ✅ Live |
| `GET` | `/api/beers` | Beers by brewery, search, style filter | ✅ | ✅ Live |
| `POST` | `/api/beers` | Create a beer | ✅ | ✅ Live |
| `GET` | `/api/profiles` | Search profiles or get own profile | ✅ | ✅ Live |
| `PATCH` | `/api/profiles` | Update profile fields | ✅ | ✅ Live |
| `GET` | `/api/friends` | List friendships + pending requests | ✅ | ✅ Live |
| `POST` | `/api/friends` | Send friend request | ✅ | ✅ Live |
| `PATCH` | `/api/friends` | Accept / block request | ✅ | ✅ Live |
| `DELETE` | `/api/friends` | Remove friendship | ✅ | ✅ Live |

---

## 🚧 Planned Routes (Not Yet Built)

| URL | Description | Sprint | Priority |
|-----|-------------|--------|--------|
| `/brewery-admin/claim` | Brewery claim + verification flow | Sprint 3 | 🔴 High |
| `/display/[brewery_id]` | TV display app — live taproom board | Sprint 5 | 🟠 Medium |
| `/recap/[period]` | Year in Beer / Pint Rewind shareable recap | Sprint 4 | 🟡 Medium |
| `/for-breweries` | Marketing landing page for brewery owners | Sprint 6 | 🟡 Medium |
| `/api/loyalty/stamp` | Award a loyalty stamp on check-in | Sprint 3 | 🔴 High |
| `/api/loyalty/redeem` | Redeem a loyalty reward (QR flow) | Sprint 3 | 🔴 High |
| `/api/promotions` | Fetch active promotions by brewery/location | Sprint 3 | 🟡 Medium |
| `/api/insights/[brewery_id]` | Brewery location intelligence | Sprint 5 | 🔵 Later |
| `/api/recap/[user_id]` | Generate recap data for a period | Sprint 4 | 🟡 Medium |

---

## 🚀 How to Run

```bash
# 1. Install dependencies (first time only)
npm install

# 2. Set up environment variables
# Create .env.local in the project root:
NEXT_PUBLIC_SUPABASE_URL=https://uadjtanoyvalnmlbnzxk.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# 3. Run the dev server
npm run dev
# → App available at http://localhost:3000

# 4. Build check (run before committing)
npm run build
```

### First-Time Database Setup (run in order in Supabase SQL Editor)
1. `supabase/schema.sql` — creates all 11 tables + RLS policies + triggers
2. `supabase/seeds/seed.sql` — seeds 35 achievement definitions
3. `supabase/migrations/001_brewery_accounts.sql` — adds brewery_accounts, loyalty, promotions
4. `supabase/seeds/002_test_brewery.sql` — creates test brewery + connects to your account

---

## 🗄️ Supabase

| Resource | URL |
|----------|-----|
| Dashboard | https://supabase.com/dashboard/project/uadjtanoyvalnmlbnzxk |
| SQL Editor | https://supabase.com/dashboard/project/uadjtanoyvalnmlbnzxk/sql |
| Auth Users | https://supabase.com/dashboard/project/uadjtanoyvalnmlbnzxk/auth/users |
| Storage | https://supabase.com/dashboard/project/uadjtanoyvalnmlbnzxk/storage/buckets |
| Table Editor | https://supabase.com/dashboard/project/uadjtanoyvalnmlbnzxk/editor |
| API Docs | https://supabase.com/dashboard/project/uadjtanoyvalnmlbnzxk/api |

---

## 📁 Key Files Quick Reference

| What | Path |
|------|------|
| Global styles + theme tokens | `app/globals.css` |
| Root layout + fonts | `app/layout.tsx` |
| DB types | `types/database.ts` |
| Supabase client | `lib/supabase/client.ts` |
| Supabase server | `lib/supabase/server.ts` |
| XP + leveling | `lib/xp/index.ts` |
| Achievement definitions (35) | `lib/achievements/definitions.ts` |
| Open Brewery DB client | `lib/openbrewerydb/index.ts` |
| Theme provider | `components/theme/ThemeProvider.tsx` |
| Theme toggle | `components/theme/ThemeToggle.tsx` |
| Brewery admin nav | `components/brewery-admin/BreweryAdminNav.tsx` |
| Check-in modal | `components/checkin/CheckinModal.tsx` |
| App navigation | `components/layout/AppNav.tsx` |
| Schema SQL | `supabase/schema.sql` |
| Seed — achievements | `supabase/seeds/seed.sql` |
| Seed — test brewery | `supabase/seeds/002_test_brewery.sql` |
| Migration 001 | `supabase/migrations/001_brewery_accounts.sql` |
| Product roadmap | `docs/strategy/roadmap.md` |
| Brand guide | `docs/strategy/brand-guide.md` |
| Competitive analysis | `docs/strategy/competitive-differentiation.md` |
| Sales playbook | `docs/sales/sales-playbook-v1.md` |
| Bug tracker | `docs/bugs/` |
| Requirements | `docs/requirements/` |
| Meeting notes | `docs/meetings/` |

---

*Updated automatically each sprint by Jordan. If a URL is wrong, file a bug.*
