# HopTrack Product Roadmap
**Last updated:** 2026-03-24
**PM:** Morgan (Project Owner)

---

## ✅ Sprint 1 — Foundation (Complete)
**Theme:** Core infrastructure, design system, auth, landing page

- [x] Next.js 16 + Tailwind v4 + Supabase setup
- [x] Design system (dark theme, gold accent, Playfair Display)
- [x] Auth (Google OAuth + email/password, signup flow)
- [x] Database schema (11 tables + RLS policies)
- [x] Landing page (marketing, hero, features)
- [x] App shell + navigation (desktop sidebar + mobile bottom nav)
- [x] Check-in modal (5-step flow)
- [x] Core components (StarRating, BeerCard, BreweryCard, CheckinCard, AchievementBadge)

---

## ✅ Sprint 2 — Consumer App (Complete)
**Theme:** All consumer-facing pages live

- [x] Home feed (activity, XP progress, weekly stats)
- [x] Brewery detail page
- [x] Beer detail page
- [x] Explore page (search + map placeholder)
- [x] Profile page (stats, achievements, journal)
- [x] Friends & leaderboards page
- [x] Achievements page (35 achievements, 6 categories)
- [x] Notifications page
- [x] Settings page
- [x] API routes (check-ins, breweries, beers, profiles, friends)
- [x] Hooks (useAuth, useCheckin, useBreweries)
- [x] XP/leveling system (20 levels)
- [x] Achievement definitions (35 achievements)

---

## ✅ Sprint 3 — Brewery Platform (Complete)
**Theme:** B2B brewery admin dashboard

- [x] Brewery admin route group + layout
- [x] Brewery dashboard (stats, recent check-ins, top beers)
- [x] Analytics page (30-day trend, busiest days, top styles, rating distribution)
- [x] Loyalty program display
- [x] Promotions display
- [x] Database migrations (brewery_accounts, loyalty_programs, loyalty_cards, promotions)
- [x] Test brewery seed data (Pint & Pixel Brewing Co.)
- [x] 12 test users + 69 realistic check-ins over 30 days
- [x] RLS policy: brewery admins can read all their brewery check-ins
- [x] Requirements validation process established (Casey QA)

---

## 🚀 Sprint 4 — Polish & Consumer Loop (Current)
**Theme:** Fix known bugs, wire real auth, close the consumer loop
**Start:** 2026-03-24

### Bug Fixes (Day 1 — do first)
- [ ] Fix AppNav left sidebar styling (out of place, contrast issues)
- [ ] Fix star rating final star size bug
- [ ] Wire check-in button to destination
- [ ] Light/dark theme toggle (Settings + AppNav)

### Consumer App Wiring
- [ ] Connect app/(app)/layout.tsx to real Supabase auth session
- [ ] Connect AppNav to real username + unread notification count
- [ ] Wire CheckinModal submit to useCheckin hook (remove setTimeout mock)
- [ ] Fix SkeletonLoader style prop TypeScript error

### New Features
- [ ] Profile: favorite beer selector + high-quality banner image (Unsplash)
- [ ] Brewery tap list editor (CRUD in brewery admin)
- [ ] Brewery claim flow (/brewery-admin/claim)
- [ ] Loyalty stamp card on brewery detail page (consumer view)

---

## 📋 Sprint 5 — Gamification & Social (Planned)
**Theme:** Make the social loop addictive
**Estimated start:** 2026-03-31

- [ ] Domestic beer flag + "How American Are You" achievement
- [ ] Slow seller promotion push notifications
- [ ] Brewery Wrapped-style monthly recap (brewery admin)
- [ ] User Pint Rewind recap (shareable card)
- [ ] Friends activity feed improvements
- [ ] Push notifications (Supabase Edge Functions + Resend email)
- [ ] Brewery QR code for loyalty redemption

---

## 📋 Sprint 6 — Premium Features (Planned)
**Theme:** Premium B2B tier features
**Estimated start:** 2026-04-07

- [ ] TV display app (/display/[brewery_id]) — live Supabase Realtime board
- [ ] Location-based brewery insights (what styles sell near you)
- [ ] Weekly analytics email digest (brewery admins)
- [ ] Brewery API access (Cask tier)
- [ ] Map view (Mapbox integration on Explore page)
- [ ] App Store / Play Store preparation

---

## 📋 Sprint 7 — Launch Prep (Planned)
**Estimated start:** 2026-04-14

- [ ] Performance audit + optimization
- [ ] Accessibility review (WCAG 2.1 AA)
- [ ] SEO (OG images, metadata, sitemap)
- [ ] Error monitoring (Sentry)
- [ ] Analytics (Posthog or Mixpanel)
- [ ] App Store screenshots (light theme)
- [ ] Beta user onboarding flow
- [ ] Pricing page + Stripe integration

---

## 🏗️ Infrastructure Roadmap (Riley)

| Item | Sprint | Status |
|------|--------|--------|
| Supabase Storage (brewery images) | 4 | Planned |
| Supabase Edge Functions (achievement eval) | 4 | Planned |
| Image CDN (Supabase transforms) | 4 | Planned |
| Scheduled jobs (weekly recaps) | 5 | Planned |
| Realtime subscriptions (TV display) | 6 | Planned |
| Email (Resend integration) | 5 | Planned |
| Error monitoring (Sentry) | 7 | Planned |
| Analytics pipeline | 7 | Planned |

---

## 💰 Revenue Milestones (Taylor + Sam)

| Milestone | Target | Notes |
|-----------|--------|-------|
| 10 brewery accounts | Sprint 5 | Early access / free trial |
| 100 consumer users | Sprint 5 | Organic from Austin launch |
| First paid brewery ($49 Tap tier) | Sprint 6 | After loyalty feature ships |
| 50 paid breweries | Sprint 7 | Pre-launch push |
| 500 paid breweries | 6 months post-launch | $75K MRR target |

---

## 🐛 Known Bugs

| Bug | Severity | Sprint | Logged |
|-----|----------|--------|--------|
| AppNav left bar contrast + placement | Medium | 4 | 2026-03-24 |
| Star rating final star too small | Medium | 4 | 2026-03-24 |
| Check-in button has no destination | High | 4 | 2026-03-24 |
| Light/dark theme contrast on page elements | Medium | 4 | 2026-03-24 |
| SkeletonLoader style prop TS error | Low | 4 | 2026-03-23 |
| app/(app)/layout.tsx uses placeholder user | High | 4 | 2026-03-23 |
| SettingsClient.tsx uses style jsx | Low | 4 | 2026-03-23 |
| CheckinModal submit is mocked (setTimeout) | High | 4 | 2026-03-23 |

---

*Roadmap is a living document. Updated each sprint by Morgan + Sam.*

---

## Sprint 6 — Platform Hardening & UX Redesign
**Target:** Week of 2026-03-31
**Theme:** Fix the foundation before we build higher

### P0 — Must Ship
| # | Item | Owner | REQ/BUG |
|---|------|-------|---------|
| 1 | Fix star rating hover/persist bug | Jordan | BUG-009 |
| 2 | Superadmin panel (`/superadmin`) | Jordan + Riley | REQ-012 |
| 3 | Check-in / Beer Review separation | Alex + Jordan | REQ-013 |
| 4 | Beer permissions — brewery-only add | Jordan + Casey | REQ-014 |

### P1 — Should Ship
| # | Item | Owner | REQ/BUG |
|---|------|-------|---------|
| 5 | Enhanced brewery stats (consumer page) | Jordan + Alex | REQ-015 |
| 6 | Brewery claim verification queue (superadmin) | Jordan | REQ-012 |
| 7 | Notion workspace setup + doc migration | Morgan + Sam | - |

### P2 — Nice to Have
| # | Item | Owner | REQ |
|---|------|-------|-----|
| 8 | Pint Rewind recap page (brewery admin) | Jordan | REQ-005 |
| 9 | Domestic beer achievement | Jordan | REQ-016 |
| 10 | Server-side flavor tag cap enforcement | Jordan | REQ-010 |

### New REQs Created This Sprint
- REQ-012: Superadmin Panel
- REQ-013: Check-in / Beer Review Separation  
- REQ-014: Beer Permissions (brewery-only)
- REQ-015: Enhanced Brewery Stats
- REQ-016: Domestic Beer Achievement

### New Bugs Logged
- BUG-009: Star rating hover/persist bug (P0, fix before Sprint 6)
